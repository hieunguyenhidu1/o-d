package com.example.iocDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IocDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IocDemoApplication.class, args);
	}

}
