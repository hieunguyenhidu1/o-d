package com.example.springProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProfileApplication.class, args);
	}

}
